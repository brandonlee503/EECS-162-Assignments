#ifndef PPLAYER_H
#define PPLAYER_H

#include "PCARD.h"
#include "PDECK.h"

using namespace std;

class PPLAYER{
private:
	int points;
	PCARD *hand;
	PCARD empty_pcard;
public:
	PPLAYER();

	string return_hand(int);

	void add_point(int);
	void print_point();

	void print_hand();
	void reset_hand();
	void draw_card(PCARD, int);
	void remove_card(int);

	int two_check();
	int three_check();
	int four_check();
	int five_check();
	int six_check();
	int seven_check();
	int eight_check();
	int nine_check();
	int ten_check();
	int jack_check();
	int queen_check();
	int king_check();
	int ace_check();

	int check_threeofkind();
	int check_straight();
	int check_flush();
	int check_fullhouse();
	int check_fourofkind();
};

#endif