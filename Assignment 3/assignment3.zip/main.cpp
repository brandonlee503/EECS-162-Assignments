/********************************************************************* 
 ** Program Filename: main.cpp
 ** Author: Brandon Lee
 ** Date: 5/9/14
 ** Description: Assignment 3
 ** Input: Which game you want to play
 ** Output: Game
 *********************************************************************/ 

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <ctime>

#include "CARD.h"
#include "DECK.h"
#include "PLAYER.h"
#include "GAME.h"

#include "PCARD.h"
#include "PDECK.h"
#include "PPLAYER.h"
#include "PGAME.h"

using namespace std;

int main(){
	int x=0;
	cout << "\tWELCOME TO ASSIGNMENT 3" << endl;
	cout << "\tPress 1 to play Gofish or 2 to play Poker" << endl;
	cin >> x;
	while(x != 1 && x != 2){
		cout << "Please enter valid input: " << endl;
		cin >> x;
	}
	if(x==1){
		DECK gdeck;
		CARD currentcard;
		gdeck.print_deck();
		gdeck.shuffle_deck();
		GAME goldfish;
		goldfish.ask_playernum(gdeck, currentcard);
	}
	else if(x==2){
		PDECK pdeck;
		PCARD pcard;
		PGAME poker;
	}
	return 0;
}
