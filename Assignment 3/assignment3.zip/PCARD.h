#ifndef PCARD_H
#define PCARD_H

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <ctime>

using namespace std;

class PCARD{
private:
	string rank;
	string suit;
public:
	PCARD();
	PCARD(string rankc, string suitc);
	string print_card();
	string get_rank();
	string get_suit();
};

#endif