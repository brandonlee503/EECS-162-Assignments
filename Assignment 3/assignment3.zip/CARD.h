#ifndef CARD_H
#define CARD_H

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <ctime>

using namespace std;

class CARD{
private:
	string rank;
	string suit;
public:
	CARD();
	CARD(string rankc, string suitc);
	string print_card();
	string get_rank();
};

#endif