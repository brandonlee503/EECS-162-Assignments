#ifndef DECK_H
#define DECK_H

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <ctime>

#include "CARD.h"

using namespace std;

class DECK{
private:
	CARD *deckarray;
	CARD *cardfill;
	CARD index;
	int avaliablecards;
public:
	DECK();
	void shuffle_deck();
	void print_deck();
	CARD deckreturncard();
};

#endif