#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <ctime>

#include "PCARD.h"

using namespace std;

PCARD::PCARD(){

}

PCARD::PCARD(string rankc, string suitc){
	rank = rankc;
	suit = suitc;
}

/*********************************************************************
 ** Function: print_card()
 ** Description: Brings in check_input and checks if user inputted integers
 ** Parameters: N/A
 ** Preconditions: Argments have been passed
 ** Return: String
 *********************************************************************/

string PCARD::print_card(){
	return (rank +" of "+ suit);
}

/*********************************************************************
 ** Function: get_rank()
 ** Description: Brings in check_input and checks if user inputted integers
 ** Parameters: N/A
 ** Preconditions: Argments have been passed
 ** Return: String
 *********************************************************************/

string PCARD::get_rank(){
	return rank;
}

/*********************************************************************
 ** Function: get_suit()
 ** Description: Brings in check_input and checks if user inputted integers
 ** Parameters: N/A
 ** Preconditions: Argments have been passed
 ** Return: String
 *********************************************************************/

string PCARD::get_suit(){
	return suit;
}