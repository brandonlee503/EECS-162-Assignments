#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <ctime>

#include "PPLAYER.h"

using namespace std;

PPLAYER::PPLAYER(){
	points=0;
	hand= new PCARD[5];
}

string PPLAYER::return_hand(int i){
	return hand[i].get_rank();
}

void PPLAYER::add_point(int i){
	points=points+i;
}

void PPLAYER::print_point(){
	cout << "You now have "<< points << " points!" << endl;
}

/*********************************************************************
 ** Function: draw_card
 ** Description: Draws card
 ** Parameters: N/A
 ** Preconditions: Argments have been passed
 ** Return: cards
 *********************************************************************/

void PPLAYER::draw_card(PCARD newcard, int i){
	hand[i]=newcard;
}

/*********************************************************************
 ** Function: print_hand(CARD newcard)
 ** Description: prints card
 ** Parameters: N/A
 ** Preconditions: Argments have been passed
 ** Return: printed card
 *********************************************************************/
void PPLAYER::print_hand(){
	for(int i=0; i<5; i++){
			cout<< i+1 << " " << hand[i].print_card() << endl;
	}
}

void PPLAYER::reset_hand(){
	for(int j=0; j<5; j++){
		hand[j]=empty_pcard;
	}
}

/*********************************************************************
 ** Function: remove_card
 ** Description: removes cards once pair is found
 ** Parameters: N/A
 ** Preconditions: Argments have been passed
 ** Return: ends game
 *********************************************************************/
void PPLAYER::remove_card(int cardnum){
	hand[cardnum]=empty_pcard;
}

/*********************************************************************
 ** Function: two_check()
 ** Description: Checks if there are " " card in player hand
 ** Parameters: N/A
 ** Preconditions: Argments have been passed
 ** Return: Number of that card
 *********************************************************************/
int PPLAYER::two_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="2")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

int PPLAYER::three_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="3")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

int PPLAYER::four_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="4")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

int PPLAYER::five_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="5")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

int PPLAYER::six_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="6")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

int PPLAYER::seven_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="7")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

int PPLAYER::eight_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="8")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

int PPLAYER::nine_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="9")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
	
	return 4;
}

int PPLAYER::ten_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="10")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

int PPLAYER::jack_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="Jack")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

int PPLAYER::queen_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="Queen")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

int PPLAYER::king_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="King")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

int PPLAYER::ace_check(){
	int counter=0;
	for(int i=0; i<5; i++){
		if(hand[i].get_rank()=="Ace")
			counter++;
	}
	if(counter==1)
		return 1;
	if(counter==2)
		return 2;
	if(counter==3)
		return 3;
	if(counter==4)
		return 4;
	else
		return 0;
}

/*********************************************************************
 ** Function: check_threeofkind()
 ** Description: Checks if there is a winning hand
 ** Parameters: N/A
 ** Preconditions: Argments have been passed
 ** Return: Point value
 *********************************************************************/
int PPLAYER::check_threeofkind(){
	if(two_check()==3 || three_check()==3 || four_check()==3){
		cout << "Three of a Kind! +10" << endl;
		return 10;
	}
	if(five_check()==3 || six_check()==3 || seven_check()==3){
		cout << "Three of a Kind! +10" << endl;
		return 10;
	}
	if(eight_check()==3 || nine_check()==3 || ten_check()==3){
		cout << "Three of a Kind! +10" << endl;
		return 10;
	}
	if(ace_check()==3 || queen_check()==3 || king_check()==3 || jack_check()==3){
		cout << "Three of a Kind! +10" << endl;
		return 10;
	}
	else
		return 0;
}

int PPLAYER::check_straight(){
	if(ace_check()==1&&two_check()==1&&three_check()==1&&four_check()==1&&five_check()==1){
		cout << "Straight! +15" << endl;
		return 15;
	}
	if(two_check()==1&&three_check()==1&&four_check()==1&&five_check()==1&&six_check()==1){
		cout << "Straight! +15" << endl;
		return 15;
	}
	if(three_check()==1&&four_check()==1&&five_check()==1&&six_check()==1&&seven_check()==1){
		cout << "Straight! +15" << endl;
		return 15;
	}
	if(four_check()==1&&five_check()==1&&six_check()==1&&seven_check()==1&&eight_check()==1){
		cout << "Straight! +15" << endl;
		return 15;
	}
	if(five_check()==1&&six_check()==1&&seven_check()==1&&eight_check()==1&&nine_check()==1){
		cout << "Straight! +15" << endl;
		return 15;
	}
	if(six_check()==1&&seven_check()==1&&eight_check()==1&&nine_check()==1&&ten_check()==1){
		cout << "Straight! +15" << endl;
		return 15;
	}
	if(seven_check()==1&&eight_check()==1&&nine_check()==1&&ten_check()==1&&jack_check()==1){
		cout << "Straight! +15" << endl;
		return 15;
	}
	if(eight_check()==1&&nine_check()==1&&ten_check()==1&&jack_check()==1&&queen_check()==1){
		cout << "Straight! +15" << endl;
		return 15;
	}
	if(nine_check()==1&&ten_check()==1&&jack_check()==1&&queen_check()==1&&king_check()==1){
		cout << "Straight! +15" << endl;
		return 15;
	}
	else 
		return 0;
}

int PPLAYER::check_flush(){
	int j=0, counter=0;
	for(int i=1; i<5; i++){
		if(hand[j].get_suit()==hand[i].get_suit())
			counter++;
		j++;
		}
		if(counter==5){
			cout << "Flush! +20" << endl;
			return 20;
		}
		else 
			return 0;
}

int PPLAYER::check_fullhouse(){

	if((two_check()==2 || three_check()==2 || four_check()==2 || five_check()==2 || six_check()==2 || seven_check()==2 ||
		eight_check()==2 || nine_check()==2 || ten_check()==2 || jack_check()==2 || queen_check()==2 || king_check()==2) &&
	   (two_check()==3 || three_check()==3 || four_check()==3 || five_check()==3 || six_check()==3 || seven_check()==3 || 
	    eight_check()==3 || nine_check()==3 || ten_check()==3 || jack_check()==3 || queen_check()==3 || king_check()==3)){

		cout << "Full House! +25" << endl;
		return 25;
	}
	else 
		return 0;
}

int PPLAYER::check_fourofkind(){
	if(two_check()==4 || three_check()==4 || four_check()==4){
		cout << "Four of a Kind! +30" << endl;
		return 30;
	}
	if(five_check()==4 || six_check()==4 || seven_check()==4){
		cout << "Four of a Kind! +30" << endl;
		return 30;
	}
	if(eight_check()==4 || nine_check()==4 || ten_check()==4){
		cout << "Four of a Kind! +30" << endl;
		return 30;
	}
	if(ace_check()==4 || queen_check()==4 || king_check()==4 || jack_check()==4){
		cout << "Four of a Kind! +30" << endl;
		return 30;
	}
	else
		return 0;
}