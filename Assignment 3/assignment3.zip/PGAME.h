#ifndef PGAME_H
#define PGAME_H

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <ctime>

#include "PCARD.h"
#include "PDECK.h"
#include "PPLAYER.h" 

using namespace std;

class PGAME{
private:
	PDECK pokerdeck;
	PPLAYER p1, p2, p3, p4, p5, p6;
	PCARD empty_pcard;
	PCARD alpha;
public:
	PGAME();

	void initiate_game(int);
	void two_player_game();
	void three_player_game();
	void four_player_game();
	void five_player_game();
	void six_player_game();
		
	void turn_player1();
	void turn_player2();
	void turn_player3();
	void turn_player4();
	void turn_player5();
	void turn_player6();

	void drawcard_player1(int);
	void drawcard_player2(int);
	void drawcard_player3(int);
	void drawcard_player4(int);
	void drawcard_player5(int);
	void drawcard_player6(int);
		
	int redraw_prompt();

	void redraw_card1();
	void redraw_card2();
	void redraw_card3();
	void redraw_card4();
	void redraw_card5();
	void redraw_card6();

	void redraw_choice_prompt1(int);
	void redraw_choice_prompt2(int);
	void redraw_choice_prompt3(int);
	void redraw_choice_prompt4(int);
	void redraw_choice_prompt5(int);
	void redraw_choice_prompt6(int);
		
	void checkwin_player1();
	void checkwin_player2();
	void checkwin_player3();
	void checkwin_player4();
	void checkwin_player5();
	void checkwin_player6();
};

#endif