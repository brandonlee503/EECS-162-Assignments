#ifndef PDECK_H
#define PDECK_H

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <ctime>

#include "PCARD.h"

using namespace std;

class PDECK{
private:
	PCARD *deckarray;
	PCARD *cardfill;
	PCARD value;
	int avaliablecards;
public:
	PDECK();
	void shuffle_deck();
	void print_deck();
	PCARD deckreturncard();
};

#endif