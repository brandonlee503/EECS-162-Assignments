#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <ctime>

#include "PGAME.h"

using namespace std;

PGAME::PGAME(){
	int user_input;
	cout << "WELCOME TO POKER!!!" << endl;
	cout << "How many Players? (2-6): ";
	cin >> user_input;
	while(user_input>6 || user_input<2){
		cout << "Please enter valid input (2-6):";
		cin >> user_input;
	}
	pokerdeck.shuffle_deck();
	initiate_game(user_input);
}

/*********************************************************************
 ** Function: initiate_game(int user_input)
 ** Description: ask for number of players
 ** Parameters: N/A
 ** Preconditions: Argments have been passed
 ** Return: int
 *********************************************************************/
void PGAME::initiate_game(int user_input){
	if(user_input==2){
		two_player_game();
	}
	if(user_input==3){
		three_player_game();
	}
	if(user_input==4){
		four_player_game();
	}
	if(user_input==5){
		five_player_game();
	}
	if(user_input==6){
		six_player_game();
	}
}

/*********************************************************************
 ** Function: two_player_game()
 ** Description: initilize player game
 ** Parameters: N/A
 ** Preconditions: Argments have been passed
 ** Return: game
 *********************************************************************/
void PGAME::two_player_game(){
	while(true){
		turn_player1();
		turn_player2();
	}
}

void PGAME::three_player_game(){
	while(true){
		turn_player1();
		turn_player2();
		turn_player3();
	}
}

void PGAME::four_player_game(){
	while(true){
		turn_player1();
		turn_player2();
		turn_player3();
		turn_player4();
	}
}

void PGAME::five_player_game(){
	while(true){
		turn_player1();
		turn_player2();
		turn_player3();
		turn_player4();
		turn_player5();

	}
}

void PGAME::six_player_game(){
	while(true){
		turn_player1();
		turn_player2();
		turn_player3();
		turn_player4();
		turn_player5();
		turn_player6();
	}
}

/*********************************************************************
 ** Function: turn_player()
 ** Description: initilize player turns
 ** Parameters: N/A
 ** Preconditions: Argments have been passed
 ** Return: player moves
 *********************************************************************/
void PGAME::turn_player1(){
	int redraw_input;
	cout << "Player 1's turn!" << endl;
	for(int i=0; i<5; i++)	
		drawcard_player1(i);
	p1.print_hand();
	redraw_input = redraw_prompt();
	if(redraw_input!=0)
		redraw_choice_prompt1(redraw_input);
	redraw_card1();		
	checkwin_player1();
	cout << endl << endl;
}

void PGAME::turn_player2(){
	int redraw_input;
	cout << "Player 2's turn!" << endl;
	for(int i=0; i<5; i++)	
		drawcard_player2(i);
	p2.print_hand();
	redraw_input = redraw_prompt();
	if(redraw_input!=0)
		redraw_choice_prompt2(redraw_input);
	redraw_card2();		
	checkwin_player2();
	cout << endl << endl;
}

void PGAME::turn_player3(){
	int redraw_input;
	cout << "Player 3's turn!" << endl;
	for(int i=0; i<5; i++)	
		drawcard_player3(i);
	p3.print_hand();
	redraw_input = redraw_prompt();
	if(redraw_input!=0)
		redraw_choice_prompt3(redraw_input);
	redraw_card3();		
	checkwin_player3();
	cout << endl << endl;
}

void PGAME::turn_player4(){
	int redraw_input;
	cout << "Player 4's turn!" << endl;
	for(int i=0; i<5; i++)	
		drawcard_player4(i);
	p4.print_hand();
	redraw_input = redraw_prompt();
	if(redraw_input!=0)
		redraw_choice_prompt4(redraw_input);
	redraw_card4();
	checkwin_player4();
	cout << endl << endl;
}

void PGAME::turn_player5(){
	int redraw_input;
	cout << "Player 5's turn!" << endl;
	for(int i=0; i<5; i++)	
		drawcard_player5(i);
	p5.print_hand();
	redraw_input = redraw_prompt();
	if(redraw_input!=0)
		redraw_choice_prompt5(redraw_input);
	redraw_card5();		
	checkwin_player5();
	cout << endl << endl;
}

void PGAME::turn_player6(){
	int redraw_input;
	cout << "Player 6's turn!" << endl;
	for(int i=0; i<5; i++)	
		drawcard_player6(i);
	p6.print_hand();
	redraw_input = redraw_prompt();
	if(redraw_input!=0)
		redraw_choice_prompt6(redraw_input);
	redraw_card6();		
	checkwin_player6();
	cout << endl << endl;
}

/*********************************************************************
 ** Function: drawcard_player1(int i)
 ** Description: Draws card
 ** Parameters: int
 ** Preconditions: inititates draw card
 ** Return: N/A
 *********************************************************************/
void PGAME::drawcard_player1(int i){
		alpha=pokerdeck.deckreturncard();
		p1.draw_card(alpha, i);
}

void PGAME::drawcard_player2(int i){
		alpha=pokerdeck.deckreturncard();
		p2.draw_card(alpha, i);
}

void PGAME::drawcard_player3(int i){
		alpha=pokerdeck.deckreturncard();
		p3.draw_card(alpha, i);
}

void PGAME::drawcard_player4(int i){
		alpha=pokerdeck.deckreturncard();
		p4.draw_card(alpha, i);
}

void PGAME::drawcard_player5(int i){
		alpha=pokerdeck.deckreturncard();
		p5.draw_card(alpha, i);
}

void PGAME::drawcard_player6(int i){
		alpha=pokerdeck.deckreturncard();
		p6.draw_card(alpha, i);
}

/*********************************************************************
 ** Function: redraw_prompt()
 ** Description: Prompts user to redraw card
 ** Parameters: int
 ** Preconditions: initiates redraw card
 ** Return: funt
 *********************************************************************/
int PGAME::redraw_prompt(){
	int redraw_input = 0;
	cout << "How many cards do you want to redraw? (1-4): ";
	cin >> redraw_input;
	while(redraw_input<0 || redraw_input>4){
		cout << "Please enter valid input (1-4): ";
		cin >> redraw_input;
	}
	return redraw_input;
}

/*********************************************************************
 ** Function: redraw_card1()
 ** Description: Draws card
 ** Parameters: N/A
 ** Preconditions: inititates draw card
 ** Return: N/A
 *********************************************************************/
void PGAME::redraw_card1(){
	for(int i=0; i<5; i++){
		if(p1.return_hand(i)==empty_pcard.get_rank()){
			alpha=pokerdeck.deckreturncard();
			p1.draw_card(alpha, i);
		}
	}
}

void PGAME::redraw_card2(){
	for(int i=0; i<5; i++){
		if(p2.return_hand(i)==empty_pcard.get_rank()){
			alpha=pokerdeck.deckreturncard();
			p2.draw_card(alpha, i);
		}
	}
}

void PGAME::redraw_card3(){
	for(int i=0; i<5; i++){
		if(p3.return_hand(i)==empty_pcard.get_rank()){
			alpha=pokerdeck.deckreturncard();
			p3.draw_card(alpha, i);
		}
	}
}

void PGAME::redraw_card4(){
	for(int i=0; i<5; i++){
		if(p4.return_hand(i)==empty_pcard.get_rank()){
			alpha=pokerdeck.deckreturncard();
			p4.draw_card(alpha, i);
		}
	}
}

void PGAME::redraw_card5(){
	for(int i=0; i<5; i++){
		if(p5.return_hand(i)==empty_pcard.get_rank()){
			alpha=pokerdeck.deckreturncard();
			p5.draw_card(alpha, i);
		}
	}
}

void PGAME::redraw_card6(){
	for(int i=0; i<5; i++){
		if(p6.return_hand(i)==empty_pcard.get_rank()){
			alpha=pokerdeck.deckreturncard();
			p6.draw_card(alpha, i);
		}
	}
}

/*********************************************************************
 ** Function: redraw_choice_prompt(int redraw_input)
 ** Description: Prompts user to redraw card
 ** Parameters: int
 ** Preconditions: initiates redraw card
 ** Return: N/A
 *********************************************************************/
void PGAME::redraw_choice_prompt1(int redraw_input){
	int input_card;
	for(int i=0; i<redraw_input; i++){
		cout << "Which card(s) do you want to redraw? (1-5): ";
		cin >> input_card;
		while(input_card-1<0||input_card-1>4){
			cout << "Please enter valid input: ";
			cin >> input_card;
		}
		if(p1.return_hand(input_card-1)==empty_pcard.get_rank()){
			i--;
			cout << "You chose that card already, please enter valid input: " << endl;
		}
		else
			p1.remove_card(input_card-1);
		}
}

void PGAME::redraw_choice_prompt2(int redraw_input){
	int input_card;
	for(int i=0; i<redraw_input; i++){	
		cout << "Which card(s) do you want to redraw? (1-5): ";
		cin >> input_card;
		while(input_card-1<0||input_card-1>4){
			cout << "Please enter valid input: " << endl;
			cin >> input_card;
		}
		if(p2.return_hand(input_card-1)==empty_pcard.get_rank()){
			i--;
			cout << "You chose that card already, please enter valid input: " << endl;
		}
		else					
			p2.remove_card(input_card-1);
		}
}

void PGAME::redraw_choice_prompt3(int redraw_input){
	int input_card;
	for(int i=0; i<redraw_input; i++){				
		cout << "Which card(s) do you want to redraw? (1-5): ";
		cin >> input_card;
		while(input_card-1<0||input_card-1>4){
			cout << "Please enter valid input: " << endl;
			cin >> input_card;
		}
		if(p3.return_hand(input_card-1)==empty_pcard.get_rank()){
			i--;
			cout << "You chose that card already, please enter valid input: " << endl;
		}
		else	
			p3.remove_card(input_card-1);
		}
}

void PGAME::redraw_choice_prompt4(int redraw_input){
	int input_card;
	for(int i=0; i<redraw_input; i++){	
		cout << "Which card(s) do you want to redraw? (1-5): ";
		cin >> input_card;
		while(input_card-1<0||input_card-1>4){
			cout << "Please enter valid input: " << endl;
			cin >> input_card;
		}
		if(p4.return_hand(input_card-1)==empty_pcard.get_rank()){
			i--;
			cout << "You chose that card already, please enter valid input: " << endl;
		}
		else
			p4.remove_card(input_card-1);
		}
}

void PGAME::redraw_choice_prompt5(int redraw_input){
	int input_card;
	for(int i=0; i<redraw_input; i++){	
		cout << "Which card(s) do you want to redraw? (1-5): ";
		cin >> input_card;
		while(input_card-1<0||input_card-1>4){
			cout << "Please enter valid input: " << endl;
			cin >> input_card;
		}
		if(p5.return_hand(input_card-1)==empty_pcard.get_rank()){
			i--;
			cout << "You chose that card already, please enter valid input: " << endl;
		}
		else
			p5.remove_card(input_card-1);
		}
}

void PGAME::redraw_choice_prompt6(int redraw_input){
	int input_card;
	for(int i=0; i<redraw_input; i++){	
		cout << "Which card(s) do you want to redraw? (1-5): ";
		cin >> input_card;
		while(input_card-1<0||input_card-1>4){
			cout << "Please enter valid input: " << endl;
			cin >> input_card;
		}
		if(p6.return_hand(input_card-1)==empty_pcard.get_rank()){
			i--;
			cout << "You chose that card already, please enter valid input: " << endl;
		}
		else
			p6.remove_card(input_card-1);
		}
}

/*********************************************************************
 ** Function: checkwin_player1()
 ** Description: Checks if player has any winning hands	
 ** Parameters: N/A
 ** Preconditions: Player has a winning hand
 ** Return: N/A
 *********************************************************************/
void PGAME::checkwin_player1(){
		cout << "Your hand after redraw: " << endl << endl;
		p1.print_hand();
		if(p1.check_flush()+p1.check_straight()==35){
			cout << "Straight Flush! +50" << endl;
			p1.add_point(50);
		}
		else{
			p1.add_point(p1.check_flush());
			p1.add_point(p1.check_straight());
		}
		p1.add_point(p1.check_fourofkind());
		if(p1.check_fullhouse()!=0)
			p1.add_point(p1.check_fullhouse());
		else
			p1.add_point(p1.check_threeofkind());
		p1.print_point();
}

void PGAME::checkwin_player2(){
		cout << "Your hand after redraw: " << endl << endl;
		p2.print_hand();
		if(p2.check_flush()+p2.check_straight()==35){
			cout << "Straight Flush! +50" << endl;
			p2.add_point(50);
		}
		else{
			p2.add_point(p2.check_flush());
			p2.add_point(p2.check_straight());
		}
		p2.add_point(p2.check_fourofkind());
		if(p2.check_fullhouse()!=0)
			p2.add_point(p1.check_fullhouse());
		else
			p2.add_point(p2.check_threeofkind());
		p2.print_point();
}

void PGAME::checkwin_player3(){
		cout << "Your hand after redraw: " << endl << endl;
		p3.print_hand();
		if(p3.check_flush()+p3.check_straight()==35){
			cout << "Straight Flush! +50" << endl;
			p3.add_point(50);
		}
		else{
			p3.add_point(p3.check_flush());
			p3.add_point(p3.check_straight());
		}
		p3.add_point(p3.check_fourofkind());
		if(p3.check_fullhouse()!=0)
			p3.add_point(p3.check_fullhouse());
		else
			p3.add_point(p3.check_threeofkind());
		p3.print_point();
}

void PGAME::checkwin_player4(){
		cout << "Your hand after redraw: " << endl << endl;
		p4.print_hand();
		if(p4.check_flush()+p4.check_straight()==35){
			cout << "Straight Flush! +50" << endl;
			p4.add_point(50);
		}
		else{
			p4.add_point(p4.check_flush());
			p4.add_point(p4.check_straight());
		}
		p4.add_point(p4.check_fourofkind());
		if(p4.check_fullhouse()!=0)
			p4.add_point(p4.check_fullhouse());
		else
			p4.add_point(p4.check_threeofkind());
		p4.print_point();
}

void PGAME::checkwin_player5(){
		cout << "Your hand after redraw: " << endl << endl;
		p5.print_hand();
		if(p5.check_flush()+p5.check_straight()==35){
			cout << "Straight Flush! +50" << endl;
			p5.add_point(50);
		}
		else{
			p5.add_point(p5.check_flush());
			p5.add_point(p5.check_straight());
		}
		p5.add_point(p5.check_fourofkind());
		if(p5.check_fullhouse()!=0)
			p5.add_point(p5.check_fullhouse());
		else
			p5.add_point(p5.check_threeofkind());
		p5.print_point();
}

void PGAME::checkwin_player6(){
		cout << "Your hand after redraw: " << endl << endl;
		p6.print_hand();
		if(p6.check_flush()+p6.check_straight()==35){
			cout << "Straight Flush! +50" << endl;
			p6.add_point(50);
		}
		else{
			p6.add_point(p6.check_flush());
			p6.add_point(p6.check_straight());
		}
		p6.add_point(p6.check_fourofkind());
		if(p6.check_fullhouse()!=0)
			p6.add_point(p6.check_fullhouse());
		else
			p6.add_point(p6.check_threeofkind());
		p6.print_point();
}